<?php
	define('URL', 'http://localhost/bookstorenew/');
?>