<?php
class _error
{
	function __construct()
	{
		echo " controller không tồn tại ";
	}
}
