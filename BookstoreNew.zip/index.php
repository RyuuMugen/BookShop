<?php
require "models/Uri.php";
require "models/Controller.php";
require "models/View.php";
require "Config/Database.php";
require "models/Database.php";
require "models/Model.php";
require "Config/Paths.php";
require "models/Pagination.php";
require "models/File.php";
$Uri= new Uri();
?>