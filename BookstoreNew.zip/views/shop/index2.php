<?php $this->view($data['page'],$data);
