<h2 style="text-align: center;margin-top: 3rem;color: red;">TÀI KHOẢN CỦA BẠN ĐÃ BỊ KHÓA </h2>
<h3 style="text-align: center;margin-top: 1rem;color: black;">Vui lòng liên lạc với quản trị viên <br> hoặc <br> </h3>
<div style="text-align: center;">
    <a href="<?= URL ?>index.php/home/login" style="text-align: center;margin-top: 1rem;">Đăng nhập bằng tài khoản khác</a>

</div>